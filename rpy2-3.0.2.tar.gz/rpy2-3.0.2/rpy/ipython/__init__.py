from . import rmagic

load_ipython_extension = rmagic.load_ipython_extension
